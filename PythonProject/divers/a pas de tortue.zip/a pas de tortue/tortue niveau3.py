import turtle

t = turtle.Turtle()

t.color("orange")

for i in range(5):
    t.forward(100)
    t.right(144)

turtle.done()