import turtle

t = turtle.Turtle()

for i in range(5):
    t.forward(100)
    t.right(72)

turtle.done